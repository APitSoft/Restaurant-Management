<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RestaurantSettingsTax extends Model
{
    protected $table = 'tbl_restaurant_settings_taxes';
}
