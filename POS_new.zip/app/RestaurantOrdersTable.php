<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RestaurantOrdersTable extends Model
{
    protected $table = 'tbl_restaurant_orders_table';

}
