<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerRestaurantSubscription extends Model
{
    protected $table = 'tbl_customer_restaurant_subscriptions';
}
