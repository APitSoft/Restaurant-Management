<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class KitchenNotification extends Model
{
    protected $table = 'tbl_kitchen_notifications';
}
