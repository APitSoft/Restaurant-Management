<!--section-footer-->
<div class="sections section-footer"> 
    <div class="container"> 
        <div class="row"> 
            <div class="col-md-4 "> 
                <p>Ask Me Communication LLC, 600 S Frederick Ave, <br> Ste 403 Gaithersburg, MD, 20877 USA<br>Call Us 131XXXXXX <br>USD</p> 
            </div> <!--col--> 
            <div class="col-md-3"> 
                <h3>Menu</h3> 
                <li> <a href="#" target="_blank"> mydemo</a> </li> 
                <li> <a href="http://Google.com" target="_blank"> Test link</a> </li> 
                <li> <a href="http://www.google.com"> only link</a> </li> 
                <li> <a href="#" target="_blank"> About us</a> </li> 
                <li> <a href="http://www.google.com" target="_blank"> google.com</a> </li> 
                <li> <a href="http://www.google.com" target="_blank"> cost</a> </li> 
                <li> <a href="#"> Testimonial</a> </li> 
            </div> <!--col--> 
            <div class="col-md-3"> 
                <h3>Others</h3> 
                <li> <a href="#" target="_blank"> others</a> </li> 
                <li> <a href="#" target="_blank"> new page demo</a> </li> 
                <li> <a href="http://#" target="_blank"> About Us</a> </li> 
                <li> <a href="http://#" target="_blank"> Privacy Policy</a> </li> 
            </div> <!--col--> 
            <div class="col-md-2"> 
                <h3>Connect with us</h3> 
                <div class="mytable social-wrap"> 
                    <div class="mycol"> 
                        <a target="_blank" href="http://www.google.com/"><i class="ion-social-googleplus"></i></a> 
                    </div> <!--col--> 
                    <div class="mycol "> 
                        <a target="_blank" href="http://www.twiter.com/"><i class="ion-social-twitter"></i></a> 
                    </div> <!--col--> 
                    <div class="mycol "> 
                        <a target="_blank" href="http://www.facebook.com/"><i class="ion-social-facebook"></i></a> 
                    </div> <!--col--> 
                    <div class="mycol "> 
                        <a target="_blank" href="http://instagram.com"><i class="ion-social-instagram"></i></a> 
                    </div> <!--col--> 
                    <div class="mycol "> 
                        <a target="_blank" href="http://youtube.com"><i class="ion-social-youtube-outline"></i></a> 
                    </div> <!--col--> 
                </div> <!--social wrap--> 
            </div> <!--col--> 
        </div> <!--row--> 
    </div> <!--container-->
</div>
<!--END section-footer-->