<!DOCTYPE html>
<html lang="en">

<body>

<p>
    Thank you for choosing "{{ $restaurant['name'] }}". 
    What to know before you go, Important dining information. 
    We may contact you about this reservation, so please ensure your email and phone number are up to date. 
    Your table will be reserved for 1 hour 30 minutes for parties of up to 4; and 2 hours for parties of 5+. 
    
</p>

<p>Thanks</p>

</body>

</html>
