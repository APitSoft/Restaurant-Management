"use strict";

CKEDITOR.replace('privacy_policy');
