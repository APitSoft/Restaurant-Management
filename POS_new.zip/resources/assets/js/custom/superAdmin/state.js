"use strict";

$(function () {
    //Initialize Select2 Elements
    $('.select2').select2()
})
